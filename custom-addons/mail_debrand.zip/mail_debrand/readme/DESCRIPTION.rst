This module modifies the functionality of emails to remove the Odoo branding,
specifically the 'Powered by Odoo'
