
This module was written to allow you to customize your Odoo instance's shortcut
icon (aka favicon). This is useful for branding purposes, but also for
integrators who have many different Odoo instances running and need to see at a
glance which browser tab does what.

The icon is shown also for portal users when the website modules are not
installed.

More info about favicon: https://en.wikipedia.org/wiki/Favicon
