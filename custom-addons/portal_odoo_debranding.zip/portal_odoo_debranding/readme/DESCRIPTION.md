This module removes Odoo branding from portal pages.
